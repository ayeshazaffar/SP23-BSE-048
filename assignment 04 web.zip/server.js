const express = require("express");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const Product = require("./models/product"); 
const expressLayouts = require("express-ejs-layouts");
const Order = require("./models/order");
const app = express();

app.use(express.static("public"));
app.use(express.static("uploads"));
app.use(cookieParser());

app.set("view engine", "ejs");
app.use(expressLayouts);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


let productsRouter = require("./routes/admin/products");
let catRout = require("./routes/admin/category");
app.use(productsRouter);
app.use(catRout);


app.get("/cart", async (req, res) => {
  let cart = req.cookies.cart || [];
  let products = await Product.find({ _id: { $in: cart } }); 
  return res.render("admin/cart", { products , layout : "admin/admin-layout"} );
});

app.get("/remove-from-cart/:id", (req, res) => {
  let cart = req.cookies.cart || [];
  
  
  cart = cart.filter(item => item !== req.params.id);
  
  
  res.cookie("cart", cart, { httpOnly: true });
  
 
  res.redirect("/cart" );
});


app.get("/add-to-cart/:id", (req, res) => {
  
  const cart = req.cookies.cart || [];
  
  
  cart.push(req.params.id);
  
  
  res.cookie("cart", cart, { httpOnly: true });
  
  
  res.redirect("/cart");
});


app.get("/cart", async (req, res) => {
  
  const cart = req.cookies.cart || [];
  
  
  const products = await Product.find({ _id: { $in: cart } });
  
 
  res.render("admin/cart", { products ,layout : "admin/admin-layout" });
});







app.get("/orders", async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("products")
      .sort({ orderDate: -1 }); 
    res.render("admin/order", { orders , layout : "admin/admin-layout" }); 
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).send("Error fetching orders");
  }
});

app.post("/delete-order/:id", async (req, res) => {
  try {
    const orderId = req.params.id;
    await Order.findByIdAndDelete(orderId); 
    res.redirect("/orders"); 
  } catch (err) {
    console.error("Error deleting order:", err);
    res.status(500).send("Error deleting the order");
  }
});


app.post("/checkout", async (req, res) => {
  const cart = req.cookies.cart || [];
  const { address } = req.body;

  if (cart.length === 0) {
    return res.status(400).send("Your cart is empty!");
  }

  
  const order = new Order({
    products: cart,
    address: address,
  });

  await order.save();

  
  res.clearCookie("cart");


  res.redirect("/orders");
});


app.get("/home", async (req, res) => {
  const products = require('./models/product')
  let p = await products.find()
  res.render("home" , {p});
});


mongoose
  .connect("mongodb://localhost:27017/pakistaniBrands")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));


app.listen(5500, () => {
  console.log("Server started at http://localhost:5500");
});
